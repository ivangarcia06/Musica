package negocio;

import java.util.ArrayList;
import java.io.FileWriter;
import java.io.IOException;
import java.io.File;
import java.util.Scanner;

public class 	Musica{
	private ArrayList<Cancion> listaCanciones = new ArrayList<>();

	public Musica(){
		cargarCanciones();
	}

	private void cargarCanciones(){
		Scanner sc = null;
		try{
			File fichero = new File("musica.csv");
			//Crea el fichero si no existe
			fichero.createNewFile();
			sc = new Scanner(fichero);
			sc.useDelimiter(",|\n");
			while(sc.hasNext()){
				listaCanciones.add(new Cancion(sc.next(), sc.next(), sc.next()));
			}
		}catch(IOException ex){
			System.out.println("Error en la lectura del fichero de cancion.");
			System.out.println("A continuación se muestra más información:");
			System.out.println(ex);
		}finally{
			if (sc != null) sc.close();
		}

	}

	public void annadir(Cancion cancion){
		listaCancions.add(cancion);
		volcarCanciones();
	}

	private void volcarCanciones(){
		FileWriter fw = null;
		try{
			fw = new FileWriter("musica.csv");
			for(Cancion cancion : listaCanciones){
				fw.write(cancion.getGenero() + "," + cancion.getArtista() + "," + cancion.getProductora()+"\n");
			}
		}catch(IOException ex){
			System.out.println("No se ha podido añadir el nuevo cancion. Error en la escritura del fichero");
			System.out.println("A continuación se muestra más información:");
			System.out.println(ex);
		}finally{
			try{
				if (fw != null) fw.close();
			}catch(IOException ex){
				System.out.println(ex);
			}
		}
	}

	@Override
        public String toString(){
		StringBuilder strCanciones = new StringBuilder();
		for(Cancion cancion : listaCanciones) strCanciones.append(cancion + "\n"); 
		return strCanciones.toString();
	}	
}
