package negocio;

public class Cancion{
	private String genero, artista, productora;

	public Cancion(String genero, String artista, String productora){
		this.genero = genero;
		this.artista = artista;
		this.productora = productora;
	}

	@Override
	public String toString(){
		return getGenero() + "," + getArtista() + "," + getProductora(); 
	}

	public String getgenero(){
		return genero;
	}

	public String getArtista(){
		return artista;
	}

	public String getProductora(){
		return productora;
	}
}
